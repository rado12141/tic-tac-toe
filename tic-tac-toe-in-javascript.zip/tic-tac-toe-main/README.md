<h1 align="center">
    <img src="tic-tac-toe-in-javascript.png" alt="Tic-Tac-Toe created in JavaScript" />
</h1>
<h4 align="center">You can read the written tutorial about the implementation on <strong><a href="https://www.webtips.dev/tic-tac-toe-in-javascript">webtips.dev</a></strong> ❌⭕</h4>
